﻿素材提供元
効果音：©BBC http://bbcsfx.acropolis.org.uk/
model
"Hurricane MkII" (https://skfb.ly/o9yHQ) by nicefilms.ua is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Spitfire" (https://skfb.ly/YYT8) by manilov.ap is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).